package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dao.AirlineDaoImpl;
import com.cg.ars.dao.IAirlineDao;
import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService {

	IAirlineDao airlineDao = null;

	public AirlineServiceImpl() {
		airlineDao = new AirlineDaoImpl();
	}

	@Override
	public List<FlightDTO> flightList() throws AirlineException {
		return airlineDao.flightList();
	}
	
	@Override
	public String getPassword(String name) throws AirlineException {
		return airlineDao.getPassword(name);
	}

	public boolean validatePassword(String password, String passData) {
		
		boolean flag=false;
		if(password.equals(passData))
		{
			flag = true;
		}
		return flag;
	}

	@Override
	public List<BookingDTO> bookingList() throws AirlineException {
		
		return airlineDao.bookingList();
	}

	@Override
	public List<PassengerDTO> passengerList(int userId) throws AirlineException {
		
		return airlineDao.passengerList(userId);
	}

	@Override
	public FlightDTO flightDetails(int flightId) throws AirlineException {
		return airlineDao.flightDetails(flightId);
	}

	@Override
	public int updateFlightInfo(FlightDTO flight) throws AirlineException {
		return airlineDao.updateFlightInfo(flight);
		
	}

	@Override
	public int deleteFlightDetails(int flightId) throws AirlineException {
		return airlineDao.deleteFlightDetails(flightId);
	}

	@Override
	public int addNewFlight(FlightDTO flight) throws AirlineException {
		
		return airlineDao.addNewFlight(flight);
	}

	@Override
	public List<PassengerDTO> passengerListById(int flightId)
			throws AirlineException {
		
		return airlineDao.passengerListById(flightId);
	}

	

}
