package com.cg.ars.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.dto.UsersDTO;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.service.AirlineServiceImpl;
import com.cg.ars.service.IAirlineService;

/**
 * Servlet implementation class AirlineController
 */
@WebServlet(urlPatterns={"/AirlineController","/success","/getFlightId","/login","/listAllFlight","/listAllBooking","/getPassengerDetails","/getFLightDetails","/UpdateFlight","/deleteFlightDetails","/addNewFlight","/listPassengerById","/addFlight"})
public class AirlineController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IAirlineService userService;
	AirlineServiceImpl userServiceImpl;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AirlineController() {
		super();
		userService = new AirlineServiceImpl();
		userServiceImpl = new AirlineServiceImpl();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();		
		String url=null;
		HttpSession session = request.getSession(true);
		int flightId;
		int result;
		switch (path) {
		case "/home":
				session = request.getSession(true);
				url = "index.jsp";
			break;
		case "/login":
			session = request.getSession(true);
			String name = request.getParameter("name");
			String password = request.getParameter("password");
			String role = request.getParameter("role");
			boolean flag = false;
			UsersDTO bean = new UsersDTO();
			try {
				String passData = userService.getPassword(name);
				System.out.println("*****************" + passData);
				flag = userServiceImpl.validatePassword(password, passData);
				if (flag) {
					url = "Administrator.jsp";
				} else
					throw new AirlineException("PASSWORD IS NOT MATCHING");

			} catch (AirlineException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/success":
			url = "Administrator.jsp";
			break;
		case "/listAllFlight":
			List<FlightDTO> flightList = new ArrayList<FlightDTO>();
			try {
				flightList = userService.flightList();
				session = request.getSession(true);
				
				session.setAttribute("flightList",flightList);
				url = "FlightDetails.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			
			break;
		case "/listAllBooking":
			List<BookingDTO> bookingList = new ArrayList<BookingDTO>();
			try {
				bookingList = userService.bookingList();
				session = request.getSession(true);
				
				session.setAttribute("bookingList",bookingList);
				url = "BookingDetails.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/getPassengerDetails" :
			System.out.println("Getting User Id");
			int userId = (Integer.parseInt(request.getParameter("userid"))) ;
			System.out.println(userId);
			List<PassengerDTO> passengerList = new ArrayList<PassengerDTO>();
			try {
				passengerList = userService.passengerList(userId);
				session = request.getSession(true);
				session.setAttribute("passengerList",passengerList);
				url = "PassengerDetails.jsp";
			}catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/getFLightDetails":
			System.out.println("Getting Flight Id");
			flightId = (Integer.parseInt(request.getParameter("flightid"))) ;
			System.out.println(flightId);
			FlightDTO flight = new FlightDTO();
			try {
				flight = userService.flightDetails(flightId);
				session = request.getSession(true);
				session.setAttribute("flight",flight);
				url = "UpdateFlight.jsp";
			}catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/UpdateFlight" :
			flightId = Integer.parseInt(request.getParameter("txtFlightId"));
			String airline = request.getParameter("txtAirline");
			String deptCity = request.getParameter("txtDeptCity");
			String arrlCity = request.getParameter("txtArrivalCity");
			String deptTime = request.getParameter("txtDeptTime");
			String arrvlTime = request.getParameter("txtArrivalTime");
			int seats = Integer.parseInt(request.getParameter("txtNoOfSeats"));
			double busFare = Double.parseDouble(request.getParameter("txtBusFare"));
			double ecoFare = Double.parseDouble(request.getParameter("txtEcoFare"));
			FlightDTO flightDto = new FlightDTO();
			flightDto.setFlightId(flightId);
			flightDto.setAirline(airline);
			flightDto.setDepartureCity(deptCity);
			flightDto.setArrivalCity(arrlCity);
			flightDto.setDepartureTime(deptTime);
			flightDto.setArrivalTime(arrvlTime);
			flightDto.setNoOfSeats(seats);
			flightDto.setBusinessFare(busFare);
			flightDto.setEconomicFare(ecoFare);
			try {
				result = userService.updateFlightInfo(flightDto);
				System.out.println("*****"+result);
				url = "UpdateSuccess.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			
			break;
		case "/deleteFlightDetails":
			System.out.println("Getting Flight Id");
			flightId = (Integer.parseInt(request.getParameter("flightid"))) ;
			System.out.println(flightId);
			try {
				result = userService.deleteFlightDetails(flightId);
				System.out.println("****"+result);
				url = "DeleteSuccess.jsp";
			}catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/getFlightId":
			url = "GetBookingId.jsp";
			break;
		case "/addFlight":
			url = "AddNewFlight.jsp";
			break;
		case "/addNewFlight":
			flightId = Integer.parseInt(request.getParameter("txtFlightId"));
			String airline1 = request.getParameter("txtAirline");
			String deptCity1 = request.getParameter("txtDeptCity");
			String arrlCity1 = request.getParameter("txtArrivalCity");
			String deptTime1 = request.getParameter("txtDeptTime");
			String arrvlTime1 = request.getParameter("txtArrivalTime");
			int seats1 = Integer.parseInt(request.getParameter("txtNoOfSeats"));
			double busFare1 = Double.parseDouble(request.getParameter("txtBusFare"));
			double ecoFare1 = Double.parseDouble(request.getParameter("txtEcoFare"));
			FlightDTO flightDto1 = new FlightDTO();
			flightDto1.setFlightId(flightId);
			flightDto1.setAirline(airline1);
			flightDto1.setDepartureCity(deptCity1);
			flightDto1.setArrivalCity(arrlCity1);
			flightDto1.setDepartureTime(deptTime1);
			flightDto1.setArrivalTime(arrvlTime1);
			flightDto1.setNoOfSeats(seats1);
			flightDto1.setBusinessFare(busFare1);
			flightDto1.setEconomicFare(ecoFare1);
			try {
				result = userService.addNewFlight(flightDto1);
				System.out.println("****"+result);
				url = "AddSuccess.jsp";
			}catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/listPassengerById":
			System.out.println("Getting Flight Id");
			int flightId1 = (Integer.parseInt(request.getParameter("txtFlightId"))) ;
			System.out.println(flightId1);
			List<PassengerDTO> passenger = new ArrayList<PassengerDTO>();
			try {
				passenger = userService.passengerListById(flightId1);
				session = request.getSession(true);
				session.setAttribute("passenger",passenger);
				url = "PassengerById.jsp";
			}catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		}
		RequestDispatcher dispatch = request
				.getRequestDispatcher(url);
		dispatch.forward(request, response);

	}

}
