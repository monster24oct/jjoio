package com.cg.exam.service;

import java.util.ArrayList;

import com.cg.exam.dto.Vehicle;
import com.cg.exam.exception.VehicleException;

public interface IVehicleService {
	public int insertVehicle(Vehicle vehicle) throws VehicleException;

	public ArrayList<Vehicle> showVehicle() throws VehicleException;
}
