package com.cg.exam.service;

import java.util.ArrayList;

import com.cg.exam.dao.IVehicleDAO;
import com.cg.exam.dao.VehicleDAOImpl;
import com.cg.exam.dto.Vehicle;
import com.cg.exam.exception.VehicleException;

/*
 * Service layer - dispatching all calls to database layer
 */
public class VehicleServiceImpl implements IVehicleService {

	IVehicleDAO vehicleDAO;

	public VehicleServiceImpl() {
		vehicleDAO = new VehicleDAOImpl();
	}

	@Override
	public int insertVehicle(Vehicle vehicle) throws VehicleException {
		return vehicleDAO.insertVehicle(vehicle);
	}

	@Override
	public ArrayList<Vehicle> showVehicle() throws VehicleException {
		return vehicleDAO.showVehicle();
	}

}
