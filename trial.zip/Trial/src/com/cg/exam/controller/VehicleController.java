package com.cg.exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.exam.dto.Vehicle;
import com.cg.exam.exception.VehicleException;
import com.cg.exam.service.IVehicleService;
import com.cg.exam.service.VehicleServiceImpl;

/**
 * Servlet implementation class BookController Acting as front controller. Where
 * all requests are dispatched from this controller
 */
@WebServlet("/VehicleController")
public class VehicleController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/** 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String operation = request.getParameter("action");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		IVehicleService service = new VehicleServiceImpl();
		if (operation != null  &&  "add".equals(operation)) {
			view = request.getRequestDispatcher("addVehicle.html");
			view.forward(request, response);
		}
		if (operation != null && "Add Vehicle".equals(operation)) {
			String vehicleName = request.getParameter("vehicleName");
			LocalDate purchaseDate = LocalDate.parse(request
					.getParameter("purchaseDate"));
			float vehiclePrice = Float.parseFloat(request
					.getParameter("vehiclePrice"));
			String vehicleCity = request.getParameter("vehicleCity");
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicleName(vehicleName);
			vehicle.setVehiclePrice(vehiclePrice);
			vehicle.setPurchaseDate(purchaseDate);
			vehicle.setVehicleCity(vehicleCity);
			try {
				int records = service.insertVehicle(vehicle);
				if (records != 0) {
					view = request.getRequestDispatcher("success.html");
					view.forward(request, response);
				} else {
					pw.println("Inserting Vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			} catch (VehicleException e) {
				pw.println("Error while inserting Vehicle details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		}
		if (operation != null && "view".equals(operation)) {
			try {
				ArrayList<Vehicle> vehicleList = service.showVehicle();
				if (vehicleList != null) {
					Iterator<Vehicle> vehicleIterator = vehicleList.iterator();
					pw.println("<body>");
					pw.println("<table border='1'>");
					pw.println("<tr>");
					pw.println("<th>Vehicle ID</th>");
					pw.println("<th>Vehicle Name</th>");
					pw.println("<th>Vehicle Purchase Date</th>");
					pw.println("<th>Vehicle Price</th>");
					pw.println("<th>Vehicle City</th>");
					pw.println("</tr>");
					while (vehicleIterator.hasNext()) {
						Vehicle vehicle = vehicleIterator.next();
						pw.println("<tr>");
						pw.println("<td>" + vehicle.getVehicleId() + "</td>");
						pw.println("<td>" + vehicle.getVehicleName() + "</td>");
						pw.println("<td>" + vehicle.getPurchaseDate() + "</td>");
						pw.println("<td>" + vehicle.getVehiclePrice() + "</td>");
						pw.println("<td>" + vehicle.getVehicleCity() + "</td>");
						pw.println("</tr>");
					}
					pw.println("</table>");
					pw.println("<a href='index.html'>Go Back to Home</a>");
					pw.println("</body>");
				} else {
					pw.println("Fetching Vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			} catch (VehicleException e) {
				pw.println("Error while fetching book details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		}
	}

}
