package com.cg.exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.exam.dto.Vehicle;
import com.cg.exam.exception.VehicleException;
import com.cg.exam.util.DBUtil;

/*
 * Database class - with all the database queries
 */
public class VehicleDAOImpl implements IVehicleDAO {

	Connection connection = null;
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.igate.book.dao.IBookDAO#insertBook(com.igate.book.dto.Book) Code
	 * to insert book record in table, returning int- specifying number of
	 * records that are inserted successfully
	 */
	@Override
	public int insertVehicle(Vehicle vehicle) throws VehicleException {
		connection = DBUtil.obtainConnection();
		String sql = "INSERT INTO Vehicle VALUES(vehicle_seq.nextval,?,?,?,?)";
		int recordInserted = 0;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, vehicle.getVehicleName());
			preparedStatement.setDate(2,
					java.sql.Date.valueOf(vehicle.getPurchaseDate()));
			preparedStatement.setFloat(3, vehicle.getVehiclePrice());
			preparedStatement.setString(4, vehicle.getVehicleCity());

			recordInserted = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new VehicleException("Error while inserting values::"
					+ e.getMessage());
		}
		return recordInserted;
	}

	/*
	 * (non-Javadoc)
	 * @see com.igate.book.dao.IBookDAO#showBooks()
	 * Fetching book records from table. Storing in ArrayList and returning arraylist of type Book 
	 */
	@Override
	public ArrayList<Vehicle> showVehicle() throws VehicleException {
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		connection = DBUtil.obtainConnection();
		String sql = "SELECT VEHICLE_ID,VEHICLE_NAME,PURCHASE_DATE,PRICE,PRICE FROM VEHICLE";
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sql);
			while (rsSet.next()) {
				Vehicle vehicle = new Vehicle();
				vehicle.setVehicleId(rsSet.getInt("VEHICLE_ID"));
				vehicle.setVehicleName(rsSet.getString("VEHICLE_NAME"));
				vehicle.setPurchaseDate(rsSet.getDate("PURCHASE_DATE").toLocalDate());
				vehicle.setVehiclePrice(rsSet.getFloat("PRICE"));
				vehicle.setVehicleCity(rsSet.getString("PRICE"));

				vehicleList.add(vehicle);
			}
		} catch (SQLException e) {
			throw new VehicleException("Error while fetching values::"
					+ e.getMessage());
		}
		return vehicleList;

	}
}
