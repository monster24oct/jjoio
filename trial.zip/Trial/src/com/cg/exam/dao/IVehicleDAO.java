package com.cg.exam.dao;

import java.util.ArrayList;

import com.cg.exam.dto.Vehicle;
import com.cg.exam.exception.VehicleException;

public interface IVehicleDAO {
	public int insertVehicle(Vehicle vehicle) throws VehicleException;
	public ArrayList<Vehicle> showVehicle() throws VehicleException;
}
