package com.cg.exam.dto;

import java.time.LocalDate;

public class Vehicle {
	private int vehicleId;
	private String vehicleName;
	private LocalDate purchaseDate;
	private float vehiclePrice;
	private String vehicleCity;

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public float getVehiclePrice() {
		return vehiclePrice;
	}

	public void setVehiclePrice(float vehiclePrice) {
		this.vehiclePrice = vehiclePrice;
	}

	public String getVehicleCity() {
		return vehicleCity;
	}

	public void setVehicleCity(String vehicleCity) {
		this.vehicleCity = vehicleCity;
	}

	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vehicle(int vehicleId, String vehicleName, LocalDate purchaseDate,
			float vehiclePrice, String vehicleCity) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleName = vehicleName;
		this.purchaseDate = purchaseDate;
		this.vehiclePrice = vehiclePrice;
		this.vehicleCity = vehicleCity;
	}

	@Override
	public String toString() {
		return "Book [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName
				+ ", purchaseDate=" + purchaseDate + ", vehiclePrice="
				+ vehiclePrice + ", vehicleCity=" + vehicleCity + "]";
	}

}
