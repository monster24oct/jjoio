create Sequence vehicle_seq;

create table vehicle(vehicle_Id number primary key,
vehicle_name varchar2(50),purchase_date date,
price number(15,2),city varchar2(20));

insert into vehicle values(vehicle_seq.nextval,'Duke','24-oct-1995',1000,'jhakkas');
insert into vehicle values(vehicle_seq.nextval,'Apache','25-oct-2017',50687,'delhi');
insert into vehicle values(vehicle_seq.nextval,'Ninja','24-nov-2018',98675,'panipat');
insert into vehicle values(vehicle_seq.nextval,'Bullet','25-oct-2019',85012,'jahannum');