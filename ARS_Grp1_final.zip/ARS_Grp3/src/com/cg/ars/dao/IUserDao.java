package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.dto.UsersDTO;
import com.cg.ars.exception.AirlineException;

public interface IUserDao {

	public int bookTicket(BookingDTO bookingDto) throws AirlineException;

	public boolean updateBooking(int userId) throws AirlineException;

	public String getPassword(String name) throws AirlineException;

	public String getRole(String name) throws AirlineException;

	public List<FlightDTO> getAvailFlights(BookingDTO bookingDto)
			throws AirlineException;

	public int getUserId(String name) throws AirlineException;

	public int addPassenger(PassengerDTO passengerDto) throws AirlineException;

	public int addUserBoking(BookingDTO bookingDto) throws AirlineException;

	public List<BookingDTO> viewAllBooking(int userId) throws AirlineException;

	public int deleteBooking(int bookingId) throws AirlineException;

	public void registerUser(UsersDTO userDto) throws AirlineException;

	List<FlightDTO> flightList() throws AirlineException;

	public FlightDTO flightDetails(int flightId) throws AirlineException;

	public int updateFlightInfo(FlightDTO flight) throws AirlineException;

	public int deleteFlightDetails(int flightId) throws AirlineException;

	public List<BookingDTO> bookingList() throws AirlineException;

	public List<PassengerDTO> passengerList(int userId) throws AirlineException;

	public List<PassengerDTO> passengerListById(int flightId)
			throws AirlineException;

	public int addNewFlight(FlightDTO flight) throws AirlineException;
}
