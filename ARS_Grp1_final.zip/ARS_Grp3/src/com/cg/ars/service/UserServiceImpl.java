package com.cg.ars.service;

import java.util.List;

import com.cg.ars.dao.IUserDao;
import com.cg.ars.dao.UserDaoImpl;
import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.dto.UsersDTO;
import com.cg.ars.exception.AirlineException;

public class UserServiceImpl implements IUserService {

	IUserDao userDao;

	public UserServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
		userDao = new UserDaoImpl();
	}

	@Override
	public List<FlightDTO> flightList() throws AirlineException {
		return userDao.flightList();
	}

	@Override
	public List<PassengerDTO> passengerList(int userId) throws AirlineException {

		return userDao.passengerList(userId);
	}

	@Override
	public List<BookingDTO> bookingList() throws AirlineException {

		return userDao.bookingList();
	}

	@Override
	public int addNewFlight(FlightDTO flight) throws AirlineException {

		return userDao.addNewFlight(flight);
	}

	@Override
	public int deleteFlightDetails(int flightId) throws AirlineException {
		return userDao.deleteFlightDetails(flightId);
	}

	@Override
	public int updateFlightInfo(FlightDTO flight) throws AirlineException {
		return userDao.updateFlightInfo(flight);

	}

	@Override
	public int bookTicket(BookingDTO bookingDto) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.bookTicket(bookingDto);
	}

	@Override
	public List<PassengerDTO> passengerListById(int flightId)
			throws AirlineException {
		return userDao.passengerListById(flightId);
	}

	@Override
	public boolean updateBooking(int userId) throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public FlightDTO flightDetails(int flightId) throws AirlineException {
		return userDao.flightDetails(flightId);
	}

	@Override
	public String getPassword(String name) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.getPassword(name);
	}

	@Override
	public String getRole(String name) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.getRole(name);
	}

	public boolean validatePassword(String password, String passData)
			throws AirlineException {
		// TODO Auto-generated method stub
		boolean flag = false;
		if (password.equals(passData)) {
			flag = true;
		}
		return flag;

	}

	@Override
	public List<FlightDTO> getAvailFlights(BookingDTO bookingDto)
			throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.getAvailFlights(bookingDto);
	}

	@Override
	public int getUserId(String name) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.getUserId(name);
	}

	@Override
	public int addPassenger(PassengerDTO passengerDto) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.addPassenger(passengerDto);
	}

	@Override
	public int addUserBoking(BookingDTO bookingDto) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.addUserBoking(bookingDto);
	}

	@Override
	public List<BookingDTO> viewAllBooking(int userId) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.viewAllBooking(userId);
	}

	@Override
	public int deleteBooking(int bookingId) throws AirlineException {
		// TODO Auto-generated method stub
		return userDao.deleteBooking(bookingId);
	}

	@Override
	public void registerUser(UsersDTO userDto) throws AirlineException {
		// TODO Auto-generated method stub
		userDao.registerUser(userDto);
	}
}
