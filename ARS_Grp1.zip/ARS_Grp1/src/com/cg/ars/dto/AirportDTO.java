package com.cg.ars.dto;

public class AirportDTO {
	
	private String airportName;
	private String airportAbbreviation;
	private String location;
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAirportAbbreviation() {
		return airportAbbreviation;
	}
	public void setAirportAbbreviation(String airportAbbreviation) {
		this.airportAbbreviation = airportAbbreviation;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

}
