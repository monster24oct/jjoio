package com.cg.ars.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ars.dto.BookingDTO;
import com.cg.ars.dto.FlightDTO;
import com.cg.ars.dto.PassengerDTO;
import com.cg.ars.dto.UsersDTO;
import com.cg.ars.exception.AirlineException;
import com.cg.ars.service.IUserService;
import com.cg.ars.service.UserServiceImpl;

/**
 * Servlet implementation class AirlineController
 */
@WebServlet("*.do")
public class AirlineController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IUserService userService;
	UserServiceImpl userServiceImpl;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AirlineController() {
		super();
		userService = new UserServiceImpl();
		userServiceImpl = new UserServiceImpl();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// String action = request.getParameter("action");
		HttpSession session = request.getSession(true);
		String path = request.getServletPath();
		String url = null;
		String userName;
		String pass;
		String mobileNumber;
		int flightId;
		int result;
		switch (path) {
		case "/validateUser.do":
			String name = request.getParameter("name");
			String password = request.getParameter("password");
			String role = request.getParameter("role");
			boolean flag = false;
			UsersDTO bean = new UsersDTO();
			try {
				int userId = userService.getUserId(name);
				
				session.setAttribute("userId", userId);
				String passData = userService.getPassword(name);
				flag = userServiceImpl.validatePassword(password, passData);
				if (flag) {
					System.out.println(flag);
					System.out.println("user Validated");
					if (role.equals("user")) {
						url = "UserMenu.jsp";
						break;
					} else {
						url = "Administrator.jsp";
						break;
					}
				} else
					throw new AirlineException("PASSWORD IS NOT MATCHING");

			} catch (AirlineException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
				break;
			}
		case "/login.do":
			url = "login.jsp";
			break;
		case "/RegisterUser.do":
			url = "addUser.jsp";
			break;
		case "/userRegistered.do":
			userName = request.getParameter("userName");
			 password = request.getParameter("password");
			pass = request.getParameter("pass");
			 role = request.getParameter("role");
			mobileNumber = request.getParameter("mobileNumber");
			if (password.equals(pass)) {
				UsersDTO userBean = new UsersDTO();
				userBean.setUserName(userName);
				userBean.setPassword(password);
				userBean.setRole(role);
				userBean.setMobileNumber(mobileNumber);
				try {
					userService.registerUser(userBean);
				} catch (AirlineException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				url = "RegisterSuccess.jsp";
				break;
			}
			else {
				url = "RegisterFail.jsp";
				break;
			}
		case "/getFLightDetails.do":
			System.out.println("Getting Flight Id");
			session = request.getSession(true);
			flightId = Integer.parseInt(request.getParameter("flightid"));
			System.out.println(flightId);
			FlightDTO flight = new FlightDTO();
			try {
				flight = userService.flightDetails(flightId);
				System.out.println("Flight details-*****");
				// session = request.getSession(true);
				session.setAttribute("flight", flight);
				url = "UpdateFlight.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/UpdateFlight.do":
			flightId = Integer.parseInt(request.getParameter("txtFlightId"));
			String airline = request.getParameter("txtAirline");
			String deptCity = request.getParameter("txtDeptCity");
			String arrlCity = request.getParameter("txtArrivalCity");
			String deptTime = request.getParameter("txtDeptTime");
			String arrvlTime = request.getParameter("txtArrivalTime");
			int seats = Integer.parseInt(request.getParameter("txtNoOfSeats"));
			double busFare = Double.parseDouble(request
					.getParameter("txtBusFare"));
			double ecoFare = Double.parseDouble(request
					.getParameter("txtEcoFare"));
			FlightDTO flightDto = new FlightDTO();
			flightDto.setFlightId(flightId);
			flightDto.setAirline(airline);
			flightDto.setDepartureCity(deptCity);
			flightDto.setArrivalCity(arrlCity);
			flightDto.setDepartureTime(deptTime);
			flightDto.setArrivalTime(arrvlTime);
			flightDto.setNoOfSeats(seats);
			flightDto.setBusFare(busFare);
			flightDto.setEcoFare(ecoFare);
			try {
				result = userService.updateFlightInfo(flightDto);
				System.out.println("*****" + result);
				url = "UpdateSuccess.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/listAllFlight.do":
			List<FlightDTO> flightList = new ArrayList<FlightDTO>();
			try {
				System.out.println("Flights List");
				flightList = userService.flightList();
				System.out.println("back to listallflight");
				session = request.getSession(true);
				session.setAttribute("flightList", flightList);
				url ="FlightDetails.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/listAllBooking.do":
			List<BookingDTO> bookingList = new ArrayList<BookingDTO>();
			try {
				bookingList = userService.bookingList();
				session = request.getSession(true);
				session.setAttribute("bookingList",bookingList);
				url = "BookingDetailsFlight.jsp";
			} catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/deleteFlightDetails.do":
			System.out.println("Getting Flight Id");
			flightId = (Integer.parseInt(request.getParameter("flightid"))) ;
			System.out.println(flightId);
			try {
				result = userService.deleteFlightDetails(flightId);
				System.out.println("****"+result);
				url = "DeleteSuccess.jsp";
			}catch (AirlineException e) {
				session.setAttribute("excep", e.getMessage());
				url = "error.jsp";
			}
			break;
		case "/showAvailFlights.do":
			BookingDTO bookDto = new BookingDTO();
			int noOfPassengers = Integer.parseInt(request
					.getParameter("noOfPassengers"));
			int records = 0;
			String source = request.getParameter("source");
			String destination = request.getParameter("destination");
			String departingDate = request.getParameter("departingDate");
			session.setAttribute("departingDate", departingDate);
			session.setAttribute("records", noOfPassengers);
			session.setAttribute("source", source);
			session.setAttribute("destination", destination);
			DateTimeFormatter formatter = DateTimeFormatter
					.ofPattern("yyyy-MM-dd");
			LocalDate date = LocalDate.parse(departingDate, formatter);

			String classType = request.getParameter("class");
			Date deptDate = null;
			System.out.println("controller showAvailFlights");
			bookDto.setSource(source);
			bookDto.setDestination(destination);
			bookDto.setBookingDate(date);
			bookDto.setNoOfPassengers(noOfPassengers);
			bookDto.setClassType(classType);
			session.setAttribute("classType", classType);
			List<FlightDTO> listFlightDto = new ArrayList<FlightDTO>();
			System.out.println("calling to get avail flights");
			try {
				listFlightDto = userService.getAvailFlights(bookDto);
				session.setAttribute("listFlightDto", listFlightDto);
				url = "FlightDetail.jsp";
				break;
			} catch (Exception e) {
				System.out.println(e);
			}
		case "/bookingTicket.do":
			url = "BookingDetails.jsp";
			break;
		case "/addPassenger.do":
			PassengerDTO passengerDto = new PassengerDTO();
			String userid = request.getParameter("UserId");
			flightId = Integer.parseInt(request.getParameter("FlightID"));
			session.setAttribute("flightId", flightId);
			System.out.println(flightId + " flight id is available");
			name = request.getParameter("Name");
			String age = request.getParameter("Age");
			String gender = request.getParameter("Gender");
			passengerDto.setUserId(Integer.parseInt(userid));
			passengerDto.setFlightId(flightId);
			passengerDto.setPassengerName(name);
			passengerDto.setPassengerAge(Integer.parseInt(age));
			passengerDto.setPassengerGender(gender);
			System.out.println("Details Added");
			try {
				records = userService.addPassenger(passengerDto);
			} catch (AirlineException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("passenger added");
			url = "BookingDetails.jsp";
			break;
		case "/success.do":
			BookingDTO bookingDto = new BookingDTO();
			source = (String) session.getAttribute("source");
			destination = (String) session.getAttribute("destination");
			departingDate = (String) session.getAttribute("departingDate");
			noOfPassengers = (Integer) session.getAttribute("records");
			classType = (String) session.getAttribute("classType");
			System.out.println(" " + source + " " + destination + " "
					+ noOfPassengers + " " + classType);
			flightId = (Integer) session.getAttribute("flightId");
			System.out.println(flightId);
			formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			date = LocalDate.parse(departingDate, formatter);
			bookingDto.setFlightId(flightId);
			bookingDto.setSource(source);
			bookingDto.setDestination(destination);
			bookingDto.setBookingDate(date);
			bookingDto.setNoOfPassengers(noOfPassengers);
			bookingDto.setClassType(classType);
			float classFare;
			if (classType.equals("business")) {
				classFare = 10;
			} else {
				classFare = 20;
			}
			double fare = noOfPassengers * classFare;
			bookingDto.setTotalFare(fare);
			int userID = (Integer) session.getAttribute("userId");
			bookingDto.setUserId(userID);
			try {
				records = userService.addUserBoking(bookingDto);
			} catch (AirlineException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("passenger added");
			url = "Success.jsp";
			break;
		case "/bookTicket.do":
			url = "BookTicket.jsp";
			break;
		case "/viewBooking.do":
			List<BookingDTO> listBookingDto = new ArrayList<BookingDTO>();
			int userId = (Integer) session.getAttribute("userId");
			try {
				listBookingDto = userService.viewAllBooking(userId);
				session.setAttribute("showBooking", listBookingDto);
			} catch (AirlineException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			url = "ViewBooking.jsp";
			break;
		/*
		 * if("updateBooking".equals(action)) { RequestDispatcher
		 * dispatch=request.getRequestDispatcher("BookTicket.jsp");
		 * dispatch.forward(request, response); }
		 */
		case "/deleteBooking.do":
			System.out.println("a gya");
			int bookingId = Integer.parseInt(request.getParameter("bookingId"));
			System.out.println(bookingId);
			try {
				int res = userService.deleteBooking(bookingId);
				System.out.println(res);
			} catch (AirlineException e) {

			}
			url = "login.jsp";
			break;
		case "/homePage.do":
			url = "UserMenu.jsp";
			break;
		case "/exitPage.do":
			url = "login.jsp";
			break;
			
			case "/getPassengerDetails.do" :
				System.out.println("Getting User Id");
				int userIDD = (Integer.parseInt(request.getParameter("userid"))) ;
				System.out.println(userIDD);
				List<PassengerDTO> passengerList = new ArrayList<PassengerDTO>();
				try {
					passengerList = userService.passengerList(userIDD);
					session = request.getSession(true);
					session.setAttribute("passengerList",passengerList);
					url = "PassengerDetails.jsp";
				}catch (AirlineException e) {
					session.setAttribute("excep", e.getMessage());
					url = "error.jsp";
				}
				break;
			case "/getFlightId.do":
				url = "GetBookingId.jsp";
				break;
			case "/listPassengerById.do":
				System.out.println("Getting Flight Id");
				int flightId1 = (Integer.parseInt(request.getParameter("txtFlightId"))) ;
				System.out.println(flightId1);
				List<PassengerDTO> passenger = new ArrayList<PassengerDTO>();
				try {
					passenger = userService.passengerListById(flightId1);
					session = request.getSession(true);
					session.setAttribute("passenger",passenger);
					url = "PassengerById.jsp";
				}catch (AirlineException e) {
					session.setAttribute("excep", e.getMessage());
					url = "error.jsp";
				}
				break;
			case "/addFlight.do":
				url = "AddNewFlight.jsp";
				break;
			case "/addNewFlight.do":
				flightId = Integer.parseInt(request.getParameter("txtFlightId"));
				String airline1 = request.getParameter("txtAirline");
				String deptCity1 = request.getParameter("txtDeptCity");
				String arrlCity1 = request.getParameter("txtArrivalCity");
				String deptTime1 = request.getParameter("txtDeptTime");
				String arrvlTime1 = request.getParameter("txtArrivalTime");
				int seats1 = Integer.parseInt(request.getParameter("txtNoOfSeats"));
				double busFare1 = Double.parseDouble(request.getParameter("txtBusFare"));
				double ecoFare1 = Double.parseDouble(request.getParameter("txtEcoFare"));
				FlightDTO flightDto1 = new FlightDTO();
				flightDto1.setFlightId(flightId);
				flightDto1.setAirline(airline1);
				flightDto1.setDepartureCity(deptCity1);
				flightDto1.setArrivalCity(arrlCity1);
				flightDto1.setDepartureTime(deptTime1);
				flightDto1.setArrivalTime(arrvlTime1);
				flightDto1.setNoOfSeats(seats1);
				flightDto1.setBusFare(busFare1);
				flightDto1.setEcoFare(ecoFare1);
				try {
					result = userService.addNewFlight(flightDto1);
					System.out.println("****"+result);
					url = "AddSuccess.jsp";
				}catch (AirlineException e) {
					session.setAttribute("excep", e.getMessage());
					url = "error.jsp";
				}
				break;
			case "/successAdmin.do":
				url = "Administrator.jsp";
				break;
		}
		RequestDispatcher dispatch = request.getRequestDispatcher(url);
		dispatch.forward(request, response);

	}
}